---
layout: page
title: Sales
permalink: /sales/
image: 06.jpg
---
## Pathways in Sales
### Overview
Professional Sales: Employees in professional sales are involved in the transfer
of goods and services in the economy, both to businesses and to individual
consumers.

### Program Details

#### Program Requirements and Recommendations
* 3 months in Job
* Managers endorsement to begin the pathway
* 8 months Marketing Immersion Program

### Sales Pathway
* Sales

### Some Career Pathways
* Market Research Analyst
* Public Relations Specialist
* Sales Manager

For More information:
- Please contact [Brigitte Coles](brigittec@driftnet.net)
