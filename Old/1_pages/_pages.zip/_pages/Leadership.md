---
layout: page
title: Leadership
permalink: /leadership/
image: 06.jpg
---
Leadership Development Program (LDP). Will provide a solid foundation of management principles that are both aspirational and practical.
## Program Details

#### Program Requirements and Recommendations
* 3 months in Job
* Managers endorsement to begin the pathway
* 8 months Marketing Immersion Program

### Leadership Pathway
* Leadership

### Some Career Pathways
* Management


For More information:
- Please contact [Brigitte Coles](brigittec@driftnet.net)
